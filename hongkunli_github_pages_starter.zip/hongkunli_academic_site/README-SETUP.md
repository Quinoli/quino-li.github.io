# Hongkun Li — GitHub Pages personal website

This starter website has two main sections:
- **Home**: professional introduction, education, work experience, skills and selected publications.
- **More**: travel, hiking, yoga and other personal interests.

## Files

- `index.html` — Home page
- `more.html` — More page
- `style.css` — shared design and responsive layout
- `script.js` — mobile navigation and automatic footer year
- `assets/photos/` — put your own approved photos here

## Before publishing — important checks

1. **Do not upload your original CV PDF unchanged.** The supplied CV contains date of birth, marital status and a personal phone number. Create a public version first; normally remove date of birth and marital status, and decide whether to publish the phone number. Keep your email only if you want it public.
2. Replace the sample publication list with verified citations. Confirm author order, author role, journal title, publication status and DOI links. The current list is a starter draft, not a verified bibliography.
3. Add a PDF named `cv.pdf` to the repository root only after making a public-safe version. The starter site does not include the original CV.
4. Replace the photo placeholders listed below with your own images. Use photos you own or have permission to publish, and avoid images that reveal other people's private information or precise home locations.
5. Check the spelling of your name and email address, all links, mobile layout and the published URL.
6. Public GitHub repositories and GitHub Pages sites can be viewed by anyone. Do not upload private documents, unpublished research data, credentials or confidential employer information.

## Photo filenames

Put your selected photos in `assets/photos/` using these exact filenames, or update the corresponding `src` paths in `more.html`:

- `travel-01.jpg`
- `hiking-01.jpg`
- `travel-02.jpg`
- `travel-03.jpg`
- `yoga-01.jpg`

The site expects landscape or portrait JPG images and crops them to fit the layout. Images around 1200–1800 pixels on the long edge are usually sufficient. Compress large photos before uploading so the page loads quickly. If you use `.webp` or `.png`, update the filenames in `more.html`.

## Upload to your existing repository

Your screenshot shows the repository `Quinoli/quino-li.github.io` on the `main` branch. This package is designed to be uploaded into that repository's **root**, alongside `.gitignore` and `README.md`.

### Option A — upload through the GitHub website

1. Unzip this package on your computer.
2. Open `Quinoli/quino-li.github.io` → branch `main`.
3. Choose **Add file → Upload files**.
4. Upload `index.html`, `more.html`, `style.css`, `script.js`, and the `assets` folder (with your photos).
5. If your browser cannot upload a folder, create `assets/photos/` in GitHub and upload each photo there; or use GitHub Desktop.
6. Review the file list and commit the changes to `main`.
7. Open **Settings → Pages**. Ensure the publishing source is `Deploy from a branch`, branch `main`, folder `/ (root)`; save if you changed anything.
8. Wait for the deployment to finish, then open `https://quino-li.github.io/` and test both Home and More.

### Option B — GitHub Desktop

1. Install GitHub Desktop from the official site and clone `Quinoli/quino-li.github.io`.
2. Copy these files into the cloned repository root.
3. Add your photo files under `assets/photos/`.
4. Review the changes in GitHub Desktop, write a commit message such as `Add personal website pages`, and choose **Commit to main**.
5. Choose **Push origin** to upload the changes.
6. Check the published site after GitHub Pages finishes deploying.

Official documentation:
- GitHub Pages quickstart: https://docs.github.com/en/pages/quickstart
- GitHub Pages publishing sources: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site

## Update workflow

- Update Home when your role, research focus, skills or publications change.
- Update More whenever you want to add or replace a few personal photos.
- Before each job application, check the site, CV PDF and publication links.
- Keep the page honest and specific. Do not claim methods or expertise that you cannot substantiate in an interview.
